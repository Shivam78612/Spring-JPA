package org.jsp.deptemp.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.jsp.deptemp.dto.Department;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class DeptDao {
	
	@Autowired
	EntityManager manager;
	
	public Department saveDepartment(Department d) {
		manager.persist(d);
		EntityTransaction transaction=manager.getTransaction();
		transaction.begin();
		transaction.commit();
		return d;
	}
	
	
	public Department updateDepartment(Department d) {
		manager.merge(d);
		EntityTransaction transaction=manager.getTransaction();
		transaction.begin();
		transaction.commit();
		return d;
	}
	
	
	public Department findDepartmentById(int d_id) {
		return manager.find(Department.class, d_id);
	}
	
	public Department verifyDeptByIdAndPhone(int id,long phone) {
		Query q=manager.createQuery("select d from Department d where d.id=?1 and d.phone=?2");
		q.setParameter(1, id);
		q.setParameter(2, phone);
		try {
			return (Department)q.getSingleResult();
		}
		catch(NoResultException e) {
			return null;
		}
	}
	
	
	public void deleteDept(int d_id) {
		Department d=findDepartmentById(d_id);
		if(d!=null) {
			manager.remove(d);
			EntityTransaction transaction=manager.getTransaction();
			transaction.begin();
			transaction.commit();
			
		}
		
		
		
	}
	

}
