package org.jsp.deptemp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.jsp.deptemp.dto.Department;
import org.jsp.deptemp.dto.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class EmpDao {
	
	@Autowired
	EntityManager manager;
	
	public Employee saveEmployee(Employee e,int d_id) {
		Department d=manager.find(Department.class, d_id);
				if(d!=null){
					d.getEmployees().add(e);
					e.setDept(d);
					manager.persist(e);
					EntityTransaction transaction=manager.getTransaction();
					transaction.begin();
					transaction.commit();
					return e;
			
		}
				return null;
	}
	
	public Employee updateEmployee(Employee e,int d_id) {
		Department d=manager.find(Department.class, d_id);
				if(d!=null){
					d.getEmployees().add(e);
					e.setDept(d);
					manager.merge(e);
					EntityTransaction transaction=manager.getTransaction();
					transaction.begin();
					transaction.commit();
					return e;
			
		}
				return null;
	}
	
	
	
	public List<Employee> findEmployeeByDeptId(int d_id) {
		Query q=manager.createQuery("select d.employees from Department d where d.id=?1");
		q.setParameter(1, d_id);
		return q.getResultList();
	}
	
	public Employee findEmployeeByPhone(long phone) {
		Query q=manager.createQuery("select e from Employee e where e.phone=?1");
		q.setParameter(1, phone);
		try {
			return (Employee)q.getSingleResult();
		}
		catch(NoResultException e) {
			return null;
		}
	}
	
	
	public void deleteEmployee(int d_id,int e_id) {
		Department d=manager.find(Department.class, d_id);
		if(d!=null) {
			Employee e=manager.find(Employee.class, e_id);
			if(e!=null) {
				e.setDept(null);
				manager.remove(e);
				EntityTransaction transaction=manager.getTransaction();
				transaction.begin();
				transaction.commit();
				
			}
			
		}
	}

}
