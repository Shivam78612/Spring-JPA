package org.jsp.deptemp.controller;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;

import org.jsp.deptemp.config.DeptEmpConfig;
import org.jsp.deptemp.dao.DeptDao;
import org.jsp.deptemp.dao.EmpDao;
import org.jsp.deptemp.dto.Department;
import org.jsp.deptemp.dto.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;

@Controller
public class Test {
	
	static Scanner sc=new Scanner(System.in);
	
	@Autowired
	static EntityManager manager;
	
	static DeptDao ddao;
	static EmpDao edao;
	
	static {
		ApplicationContext context=new AnnotationConfigApplicationContext(DeptEmpConfig.class);
		ddao=context.getBean(DeptDao.class);
	}
	static {
		ApplicationContext context=new AnnotationConfigApplicationContext(DeptEmpConfig.class);
		edao=context.getBean(EmpDao.class);
	}
	
	
	public static void main(String[] args) {
		
		System.out.println("1:Save department");
		System.out.println("2:update department");
		System.out.println("3:find department by id");
		System.out.println("4:verify dept by id and phone");
		System.out.println("5:delete department");
		System.out.println("6:save employee");
		System.out.println("7:update employee");
		System.out.println("8:find employee by dept id");
		System.out.println("9:find employee by phone");
		System.out.println("10:delete employee");
		
		int choice=sc.nextInt();
		switch(choice) {
		
		case 1:{
			saveDept();
			break;
		}
		case 2:{
			updateDept();
			break;
		}
		case 3:{
			findDeptById();
			break;
		}
		case 4:{
			verifyDeptByIdPhone();
			break;
		}
		case 5:{
			deleteDept();
			break;
		}
		case 6:{
			saveEmp();
			break;
		}
		case 7:{
			updateEmployee();
			break;
		}
		case 8:{
			findEmpByDeptId();
			break;
		}
		case 9:{
			findEmpByPhone();
			break;
		}
		case 10:{
			deleteEmp();
			break;
		}
		}
	}

	public static void deleteEmp() {
		System.out.println("enter dept id to delete");
		int did=sc.nextInt();
		System.out.println("enter emp id to delete");
		int eid=sc.nextInt();
		edao.deleteEmployee(did, eid);
	}
		
	

	public static void findEmpByPhone() {
		
		System.out.println("enter phone to find employee");
		long phone=sc.nextLong();
		Employee e=new Employee();
		e=edao.findEmployeeByPhone(phone);
		System.out.println(e);
	}
		
	

	public static void findEmpByDeptId() {
		System.out.println("enter id to find");
		int id=sc.nextInt();
		List<Employee> list=edao.findEmployeeByDeptId(id);
		if(list.size()>0) {
			for(Employee e:list) {
				System.out.println(e);
			}
		}
			
	}
		
	

	public static void saveEmp() {
		System.out.println("enter  id to save");
		int id=sc.nextInt();
		
	
		
		
			System.out.println("enter employee name,age,phone");
			
			String name=sc.next();
			int age=sc.nextInt();
			long phone=sc.nextLong();
			Employee e=new Employee();
			e.setName(name);
			e.setAge(age);
			e.setPhone(phone);
			
			e=edao.saveEmployee(e, id);
			if(e!=null)
				System.out.println("employee saved with id:"+e.getId());
			else
				System.out.println("emp not saved");
		}
		
	
		
		public static void updateEmployee() {
			System.out.println("enter id to find");
			int id=sc.nextInt();
			
			Department d=ddao.findDepartmentById(id);
			if(d!=null) {
				System.out.println("enter id,name,age,phone to save employee");
				int eid=sc.nextInt();
				String name=sc.next();
				int age=sc.nextInt();
				long phone=sc.nextLong();
				Employee e=new Employee();
				e.setId(eid);
				e.setName(name);
				e.setAge(age);
				e.setPhone(phone);
				
				Employee emp=edao.updateEmployee(e, id);
				if(emp!=null) {
					System.out.println("employee updated with id:"+e.getId()+"with dpt id:"+d.getId());
				}
				else {
					System.out.println("employeee not updated");
				}
			}
		
		
	}

	public static void deleteDept() {
		System.out.println("enter id to delete");
		int id=sc.nextInt();
		ddao.deleteDept(id);
		
	}

	public static void verifyDeptByIdPhone() {
		System.out.println("enter id and phone to verify");
		int id=sc.nextInt();
		long phone=sc.nextLong();
		Department d=new Department();
		d=ddao.verifyDeptByIdAndPhone(id, phone);
		System.out.println(d);
		
	}

	public static void findDeptById() {
		System.out.println("enter id to find");
		int id=sc.nextInt();
		Department d=new Department();
		d=ddao.findDepartmentById(id);
		System.out.println(d);
		
	}

	public static void saveDept() {
		System.out.println("enter name,phone and address to save");
		String name=sc.next();
		long phone=sc.nextLong();
		String address=sc.next();
		Department d=new Department();
		d.setName(name);
		d.setPhone(phone);
		d.setAddress(address);
		 d=ddao.saveDepartment(d);
		System.out.println("dept saved with id:"+d.getId());
		
	}
	
	public static void updateDept() {
		System.out.println("enter id,name,phone and address to save");
		int id=sc.nextInt();
		String name=sc.next();
		long phone=sc.nextLong();
		String address=sc.next();
		Department d=new Department();
		d.setId(id);
		d.setName(name);
		d.setPhone(phone);
		d.setAddress(address);
		 d=ddao.updateDepartment(d);
		System.out.println("dept saved with id:"+d.getId());
		
	}

}
