package org.jsp.fooduserapp.controller;

import java.time.LocalDate;
import java.util.Scanner;

import javax.persistence.EntityManager;

import org.jsp.fooduserapp.MyConfig;
import org.jsp.fooduserapp.dao.FoodOrderDao;
import org.jsp.fooduserapp.dao.UserDao;
import org.jsp.fooduserapp.dto.FoodOrder;
import org.jsp.fooduserapp.dto.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;



@Controller
public class FoodController {
	
	static Scanner sc = new Scanner(System.in);
	
	@Autowired
	private EntityManager manager;
	
	static  UserDao udao;
	static FoodOrderDao fdao;
	
	static {
		ApplicationContext context  = new AnnotationConfigApplicationContext(MyConfig.class);
		udao = context.getBean(UserDao.class);
	}
	static {
		ApplicationContext context  = new AnnotationConfigApplicationContext(MyConfig.class);
		fdao = context.getBean(FoodOrderDao.class);
	}
	
	public static void main(String[] args) {
		System.out.println("1 - Save the user");
		System.out.println("2 - Update the user");
		System.out.println("3 - Verify the user by email and password");
		System.out.println("4 - Save the food order");
		System.out.println("5 - Update the food order");
		System.out.println("6 - Fethc the food order by user Id");
		System.out.println("7 - Fetch the food order by user email and password");
		System.out.println("8 - Delete the food order");
	   System.out.println("Enter Your Choice to Proceed");
		int choice = sc.nextInt();
		
		switch (choice) {
		case 1:{
			saveUser();
			break;
		}
		case 2:{
			updateUser();
			break;
		}
		case 3:{
			verifyUserByEmailAndPassword();
			break;
		}
		case 4:{
			saveFood();
			break;
		}
		case 5:{
			updateFood();
			break;
		}
		case 6:{
			fetchFoodUsigUserId();
			break;
		}
		case 7:{
			fetchFoodUsingUserEmailAndPassword();
			break;
		}
		case 8:{
			deleteFoodOrder();
			break;
		}
		
		
		}
		
	}
	public static void saveUser() {
		System.out.println("Enter your name,gender,email,phone and password");
		String namle = sc.next();
		String gender = sc.next();
		String email = sc.next();
		long phone = sc.nextLong();
		String password = sc.next();
		 User u = new User();
		 u.setName(namle);
		 u.setEmail(email);
		 u.setGender(gender);
		 u.setPhone(phone);
		 u.setPassword(password);
		 u = udao.saveUser(u);
		 System.out.println("User save successfully with the id :"+u.getId());
		
	}
	public static void updateUser() {
		System.out.println("Enter you user id to update the user");
		int uid = sc.nextInt();
		System.out.println(" Now Enter your name,gender,email,phone and password");
		String namle = sc.next();
		String gender = sc.next();
		String email = sc.next();
		long phone = sc.nextLong();
		String password = sc.next();
		 User u = new User();
		 u.setId(uid);
		 u.setName(namle);
		 u.setEmail(email);
		 u.setGender(gender);
		 u.setPhone(phone);
		
		 u.setPassword(password);
		 u = udao.updateUser(u);
		 System.out.println("User updated Successfully");
		
	}
	public static void verifyUserByEmailAndPassword() {
		System.out.println("Enter you email and password to verify the user");
		String email = sc.next();
		String password = sc.next();
		User u = new User();
		u.setEmail(email);
		u.setPassword(password);
		u = udao.verifyUserByEmailAndPassword(email, password);
	}
	
	public static void saveFood() {
		System.out.println("Enter your user id to add the food order");
		int uid = sc.nextInt();
		System.out.println("Enter your item_name,price and address");
		String item_name  = sc.next();
		double price = sc.nextDouble();
		String address = sc.next();
		FoodOrder f = new FoodOrder();
		f.setItem_name(item_name);
		f.setPrice(price);
		f.setAddress(address);
		f = fdao.saveFood(f, uid);
		System.out.println("Food Order is added successfully");
				
	}
	public static void updateFood() {
		System.out.println("Enter your user id to update the food order");
		int uid = sc.nextInt();
		System.out.println("Enter your Food id to update the food order");
		int fid = sc.nextInt();
		System.out.println("Enter your item_name,price and address");
		String item_name  = sc.next();
		double price = sc.nextDouble();
		String address = sc.next();
		FoodOrder f = new FoodOrder();
		f.setId(fid);
		f.setDelivery_time(LocalDate.now());
		f.setItem_name(item_name);
		f.setPrice(price);
		f.setAddress(address);
		f = fdao.updateFood(f, uid);
		System.out.println("Food Order is Updated successfully");
				
	}
	public static void fetchFoodUsigUserId() {
		System.out.println("Enter your user id to fetch the food");
		int uid = sc.nextInt();
		FoodOrder f = new FoodOrder();
		f = fdao.fetchFoodByUserId(uid);
		
	}
	public static void fetchFoodUsingUserEmailAndPassword() {
		System.out.println("Enter user email and password to fetch the food order");
		String email = sc.next();
		String password = sc.next();
		FoodOrder f = new FoodOrder();
		f = fdao.fetchFoodByUserEmailAndPassword(email, password);
		
	}
	public static void deleteFoodOrder() {
		System.out.println("Enter your user id to delete the food order");
		int uid = sc.nextInt();
		System.out.println("Enter your Food id now to delete the food order ");
		int fid = sc.nextInt();
		FoodOrder f = new FoodOrder();
		fdao.deleteFoodOrder(uid, fid);
		System.out.println("Food order deleted successfully");
	}

}









