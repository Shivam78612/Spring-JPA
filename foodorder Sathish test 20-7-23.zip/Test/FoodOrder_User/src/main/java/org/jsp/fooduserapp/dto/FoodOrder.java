package org.jsp.fooduserapp.dto;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;


@Entity
public class FoodOrder {
       @Id
       @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
       @CreationTimestamp       
	private LocalDate delivery_time;
       @UpdateTimestamp
       private LocalDate order_time;
	private double price;
	private String address;
	private String item_name;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn
	private User users ;
	public User getUsers() {
		return users;
	}
	public void setUsers(User users) {
		this.users = users;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public LocalDate getDelivery_time() {
		return delivery_time;
	}
	public void setDelivery_time(LocalDate delivery_time) {
		this.delivery_time = delivery_time;
	}
	public LocalDate getOrder_time() {
		return order_time;
	}
	public void setOrder_time(LocalDate order_time) {
		this.order_time = order_time;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getItem_name() {
		return item_name;
	}
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	@Override
	public String toString() {
		return "FoodOrder [id=" + id + ", delivery_time=" + delivery_time + ", order_time=" + order_time + ", price="
				+ price + ", address=" + address + ", item_name=" + item_name + "]";
	}
	
	
}
