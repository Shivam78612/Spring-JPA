package org.jsp.fooduserapp.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.jsp.fooduserapp.dto.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserDao {
	
	@Autowired
	private EntityManager manager ;
	
	public User saveUser(User u ) {
		manager.persist(u);
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		transaction.commit();
		return u;
		
	}
	public User updateUser(User u ) {
		manager.merge(u);
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		transaction.commit();
		return u;
		
	}
	public User verifyUserByEmailAndPassword(String email,String password) {
		String qry = "select u from User u where u.email = ?1 and u.password = ?2";
		Query q = manager.createQuery(qry);
		q.setParameter(1, email);
		q.setParameter(2, password);
		try {
			User u = (User) q.getSingleResult();
			System.out.println(u);
			
		}
		catch(NoResultException e) {
			System.err.println("multiple result error");
		}
		return null;
	}
	

}
