package org.jsp.fooduserapp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.jsp.fooduserapp.dto.FoodOrder;
import org.jsp.fooduserapp.dto.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class FoodOrderDao {

	
	@Autowired
	private EntityManager manager;
	
	public FoodOrder saveFood (FoodOrder food,int uid) {
		User u = manager.find(User.class, uid);
		if(u!=null) {
			u.getFoodorders().add(food);
			food.setUsers(u);
			manager.persist(food);
			EntityTransaction transaction = manager.getTransaction();
			transaction.begin();
			transaction.commit();
		}
		return food;
	}
	
	public FoodOrder updateFood (FoodOrder food,int uid) {
		User u = manager.find(User.class, uid);
		if(u!=null) {
			
			u.getFoodorders().add(food);
			food.setUsers(u);
			manager.merge(food);
			EntityTransaction transaction = manager.getTransaction();
			transaction.begin();
			transaction.commit();
		}
		return food;
	}
	
	public FoodOrder fetchFoodByUserId(int uid) {
		String qry = "select f.foodorders from User f where f.id = ?1";
		Query q = manager.createQuery(qry);
		q.setParameter(1, uid);
		List<FoodOrder> food= q.getResultList();
		for(FoodOrder f:food) {
			System.out.println(f);
		}
		return null;
		
	}
	public FoodOrder fetchFoodByUserEmailAndPassword(String email,String password) {
		String qry = "select f.foodorders from User f where f.email = ?1 and f.password = ?2";
		Query q = manager.createQuery(qry);
		q.setParameter(1, email);
		q.setParameter(2, password);
		List<FoodOrder> food= q.getResultList();
		for(FoodOrder f:food) {
			System.out.println(f);
		}
		return null;
		
	}
	
	public boolean deleteFoodOrder(int uid,int fid) {
	User u = manager.find(User.class, uid);
	if(u!=null) {
		FoodOrder f = manager.find(FoodOrder.class, fid);
		if(f!=null) {
		    f.setUsers(null);
			manager.remove(f);
			EntityTransaction transaction = manager.getTransaction();
			transaction.begin();
			transaction.commit();
			return true;
		}
	}
	return false;
	}
	
	
	
	
}
