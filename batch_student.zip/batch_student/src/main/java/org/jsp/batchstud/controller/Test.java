package org.jsp.batchstud.controller;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;

import org.jsp.batchstud.Config.BatchStudConfig;
import org.jsp.batchstud.dao.BatchDao;
import org.jsp.batchstud.dao.StudentDao;
import org.jsp.batchstud.dto.Batch;
import org.jsp.batchstud.dto.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;

@Controller
public class Test {
	

	
	static Scanner sc=new Scanner(System.in);
	
	static BatchDao bdao;
	static StudentDao sdao;
	
	static {
		ApplicationContext context=new AnnotationConfigApplicationContext(BatchStudConfig.class);
		bdao=context.getBean(BatchDao.class);
	}
	
	static {
		ApplicationContext context=new AnnotationConfigApplicationContext(BatchStudConfig.class);
		sdao=context.getBean(StudentDao.class);
		
	}
	
	public static void main(String[] args) {
		
		System.out.println("1:save batch");
		System.out.println("2:update batch");
		System.out.println("3:verify batch by id");
		System.out.println("4:verify batch by id and batchcode");
		System.out.println("5:delete batch");
		System.out.println("6:save student");
		System.out.println("7:update student");
		System.out.println("8:verify student by id and phone");
		System.out.println("9:delete student");
		
		int choice=sc.nextInt();
		
		switch(choice) {
		
		case 1:{
			saveBatch();
			break;
		}
		
		case 2:{
			updateBatch();
			break;
		}
		case 3:{
			verifyBatchById();
			break;
		}
		
		case 4:{
			verifyBatchByIdandBatchcode();
			break;
		}
		case 5:{
			deleteBatch();
			break;
		}
		
		case 6:{
			saveStudent();
			break;
		}
		
		case 7:{
			updateStudent();
			break;
		}
		case 8:{
			verifyStudentByIdnandPhone();
			break;
		}
		case 9:{
			deleteStudent();
			break;
		}
		
		
		
		}
	}

	public static void deleteStudent() {
		
		System.out.println("enter batch id to dlete");
		int bid=sc.nextInt();
		System.out.println("enter student id to dlete");
		int sid=sc.nextInt();
		sdao.deleteStudent(bid, sid);
		
	}

	public static void verifyStudentByIdnandPhone() {
		
		System.out.println("enter id and phone to verify");
		int id=sc.nextInt();
		long phone=sc.nextLong();
		Student s=new Student();
		s=sdao.verifyStudentByIdAndPhone(id, phone);
		System.out.println(s);
		
	}

	public static void saveStudent() {
		
		System.out.println("enter id to save ");
		int id=sc.nextInt();
		System.out.println("enter name,age and phone to save");
		String name=sc.next();
		int age=sc.nextInt();
		long phone=sc.nextLong();
		Student s=new Student();
		s.setName(name);
		s.setAge(age);
		s.setPhone(phone);
		 s=sdao.saveStudent(s, id);
		 if(s!=null) 
		System.out.println("student saved with id:"+s.getId());
		
	
		 else 
			 System.out.println("student not found");
		 }
	
public static void updateStudent() {
		
		System.out.println("enter id to find ");
		int id=sc.nextInt();
		Batch b=bdao.findBatchById(id);
		if(b!=null) {
		System.out.println("enter id,name,age and phone to update");
		int sid=sc.nextInt();
		String name=sc.next();
		int age=sc.nextInt();
		long phone=sc.nextLong();
		Student s=new Student();
		s.setId(sid);
		s.setName(name);
		s.setAge(age);
		s.setPhone(phone);
		Student stu=sdao.updateStudent(s, id);
		if(stu!=null)
		System.out.println("student updated with id:"+s.getId()+"with batch id:"+b.getId());
		else
			System.out.println("student not updated");
		}
		
	}

	public static void deleteBatch() {
		System.out.println("enter id to delete");
		int id=sc.nextInt();
		bdao.deleteBatch(id);
		
	}

	public static void verifyBatchByIdandBatchcode() {
		System.out.println("enter id and batchcode to verify");
		int id=sc.nextInt();
		String batchcode=sc.next();
		Batch b=new Batch();
		b=bdao.verifyBatchByIdAndBatchcode(id, batchcode);
		System.out.println(b);
		
	}

	public static void verifyBatchById() {
		
		System.out.println("enter id to verify");
		int id=sc.nextInt();
		Batch b=new Batch();
		b=bdao.findBatchById(id);
		System.out.println(b);
		
	}

	public static void saveBatch() {
		
		System.out.println("enter name and batchcode to save the batch");
		String name=sc.next();
		String batchcode=sc.next();
		Batch b=new Batch();
		b.setName(name);
		b.setBatchcode(batchcode);
		bdao.saveBatch(b);
		System.out.println("batch saved with id:"+b.getId());
		
	}
	
	
public static void updateBatch() {
		
		System.out.println("enter id, name and batchcode to save the batch");
		int id=sc.nextInt();
		String name=sc.next();
		String batchcode=sc.next();
		Batch b=new Batch();
		b.setId(id);
		b.setName(name);
		b.setBatchcode(batchcode);
		b=bdao.updateBatch(b);
		System.out.println("batch updated with id:"+b.getId());
		
	}
	
	

}
