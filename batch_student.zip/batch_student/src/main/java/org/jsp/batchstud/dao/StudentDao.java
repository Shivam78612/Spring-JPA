package org.jsp.batchstud.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.jsp.batchstud.dto.Batch;
import org.jsp.batchstud.dto.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class StudentDao {

	@Autowired
	EntityManager manager;

	public Student saveStudent(Student s, int b_id) {
		Batch b = manager.find(Batch.class, b_id);
		if (b != null) {
			b.getStudents().add(s);
			s.setBatchs(null);
			
			
			manager.persist(s);
			EntityTransaction transaction = manager.getTransaction();
			transaction.begin();
			transaction.commit();
			return  s;

		}
		return null;
	}
	
	

	public Student updateStudent(Student s, int b_id) {
		Batch b = manager.find(Batch.class, b_id);
		if (b != null) {
			b.getStudents().add(s);
			s.setBatchs(null);
			
			
			manager.merge(s);
			EntityTransaction transaction = manager.getTransaction();
			transaction.begin();
			transaction.commit();
			return  s;

		}
		return null;
	}
	
	
	
	
	
	
	public Student verifyStudentByIdAndPhone(int id,long phone) {
		Query q=manager.createQuery("select s from Student s where s.id=?1 and s.phone=?2");
		q.setParameter(1, id);
		q.setParameter(2, phone);
		try {
			return (Student)q.getSingleResult();
		}
		catch(NoResultException e) {
			return null;
		}
	}
	
	
	public void deleteStudent(int b_id,int s_id) {
		Batch b=manager.find(Batch.class, b_id);
		if(b!=null) {
			Student s=manager.find(Student.class, s_id);
			if(s!=null) {
				s.setBatchs(null);
				manager.remove(s);
				EntityTransaction transaction=manager.getTransaction();
				transaction.begin();
				transaction.commit();
				
			}
		}
	}

}
