package org.jsp.batchstud.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.jsp.batchstud.dto.Batch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BatchDao {
	
	@Autowired
	EntityManager manager;
	
	public Batch saveBatch(Batch b) {
		manager.persist(b);
		EntityTransaction transaction=manager.getTransaction();
		transaction.begin();
		transaction.commit();
		return b;
	}

	
	
	public Batch updateBatch(Batch b) {
		manager.merge(b);
		EntityTransaction transaction=manager.getTransaction();
		transaction.begin();
		transaction.commit();
		return b;
	}
	
	public Batch findBatchById(int b_id) {
		return manager.find(Batch.class, b_id);
	}
	
	public Batch verifyBatchByIdAndBatchcode(int id,String batchcode) {
		Query q=manager.createQuery("select b from Batch b where b.id=?1 and b.batchcode=?2 ");
		q.setParameter(1, id);
		q.setParameter(2, batchcode);
		try {
			return (Batch)q.getSingleResult();
		}
		catch(NoResultException e) {
			return null;
		}
	}
	
	
	
	public void deleteBatch(int b_id) {
		Batch b=manager.find(Batch.class, b_id);
		if(b!=null) {
			manager.remove(b);
			EntityTransaction transaction=manager.getTransaction();
			transaction.begin();
			transaction.commit();
			
		}
		
	}

}
