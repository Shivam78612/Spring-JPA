package org.jsp.batchstud.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Batch {

	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	private int id;
	private String name;
	private String batchcode;
	
	
	@ManyToMany
	@JoinTable(name="batch_student",joinColumns = {@JoinColumn(name="batch_id")}, inverseJoinColumns = {@JoinColumn(name="student_id")})
	public List<Student> students;


	@Override
	public String toString() {
		return "Batch [id=" + id + ", name=" + name + ", batchcode=" + batchcode + "]";
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getBatchcode() {
		return batchcode;
	}


	public void setBatchcode(String batchcode) {
		this.batchcode = batchcode;
	}


	public List<Student> getStudents() {
		return students;
	}


	public void setStudents(List<Student> students) {
		this.students = students;
	}
	
}
